note: the result of 
```
from hashlib import md5, sha1
md5(sha1(flag).hexdigest()).hexdigest()
```
 is 'dcb22c95f44ee0b45d47518874dfcdd2'